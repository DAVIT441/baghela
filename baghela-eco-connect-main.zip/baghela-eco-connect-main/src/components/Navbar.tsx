import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Leaf, User, ShoppingBag, Calendar, LogOut, PlusCircle, MessageCircle } from 'lucide-react';
import { getUser, logout } from '@/lib/localStorage';
import { useState, useEffect } from 'react';

export const Navbar = () => {
  const location = useLocation();
  const [user, setUser] = useState(getUser());

  useEffect(() => {
    setUser(getUser());
  }, [location]);

  const handleLogout = () => {
    logout();
    setUser(null);
    window.location.href = '/';
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-lg border-b shadow-soft">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-full gradient-hero flex items-center justify-center transition-smooth group-hover:scale-110">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-primary">ბაღელა</span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link 
              to="/" 
              className={`text-sm font-medium transition-smooth hover:text-primary ${
                isActive('/') ? 'text-primary' : 'text-foreground'
              }`}
            >
              ბაღები
            </Link>
            {user?.role === 'owner' && (
              <Link 
                to="/add-garden" 
                className={`text-sm font-medium transition-smooth hover:text-primary ${
                  isActive('/add-garden') ? 'text-primary' : 'text-foreground'
                }`}
              >
                <PlusCircle className="w-4 h-4 inline mr-1" />
                ბაღის დამატება
              </Link>
            )}
            <Link 
              to="/market" 
              className={`text-sm font-medium transition-smooth hover:text-primary ${
                isActive('/market') ? 'text-primary' : 'text-foreground'
              }`}
            >
              <ShoppingBag className="w-4 h-4 inline mr-1" />
              მაღაზია
            </Link>
            <Link 
              to="/calendar" 
              className={`text-sm font-medium transition-smooth hover:text-primary ${
                isActive('/calendar') ? 'text-primary' : 'text-foreground'
              }`}
            >
              <Calendar className="w-4 h-4 inline mr-1" />
              კალენდარი
            </Link>
          </div>

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <Link to="/profile">
                  <Button variant="outline" size="sm" className="gap-2">
                    <User className="w-4 h-4" />
                    <span className="hidden sm:inline">{user.name}</span>
                    <span className="text-primary font-semibold">{user.ecoPoints}🌿</span>
                  </Button>
                </Link>
                <Button variant="ghost" size="sm" onClick={handleLogout}>
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline ml-2">გასვლა</span>
                </Button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="outline" size="sm">შესვლა</Button>
                </Link>
                <Link to="/register">
                  <Button size="sm" className="gradient-hero text-white">რეგისტრაცია</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
