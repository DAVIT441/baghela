import { Leaf, Heart } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-card border-t mt-20">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full gradient-hero flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-primary">ბაღელა</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>შექმნილია</span>
            <Heart className="w-4 h-4 text-primary fill-primary" />
            <span>საქართველოსთვის</span>
          </div>
          
          <div className="text-sm text-muted-foreground">
            © 2025 ბაღელა. ყველა უფლება დაცულია.
          </div>
        </div>
      </div>
    </footer>
  );
};
