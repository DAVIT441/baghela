import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Sprout, Square } from 'lucide-react';
import { Garden } from '@/lib/localStorage';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface GardenCardProps {
  garden: Garden;
  index: number;
}

export const GardenCard = ({ garden, index }: GardenCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
    >
      <Card className="overflow-hidden shadow-card hover:shadow-hover transition-smooth group">
        <div className="relative h-56 overflow-hidden">
          <img 
            src={garden.images[0]} 
            alt={garden.title}
            className="w-full h-full object-cover transition-smooth group-hover:scale-110"
          />
          {garden.available && (
            <div className="absolute top-4 right-4 bg-primary text-white px-3 py-1 rounded-full text-sm font-medium">
              ხელმისაწვდომია
            </div>
          )}
        </div>
        
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-2 text-foreground group-hover:text-primary transition-smooth">
            {garden.title}
          </h3>
          
          <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
            {garden.description}
          </p>
          
          <div className="flex flex-wrap gap-3 mb-4">
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4 text-primary" />
              {garden.location}
            </div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Sprout className="w-4 h-4 text-secondary" />
              {garden.type}
            </div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Square className="w-4 h-4 text-accent" />
              {garden.area} მ²
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground">
              მფლობელი: {garden.ownerName}
            </span>
            <Link to={`/garden/${garden.id}`}>
              <Button size="sm" className="gradient-hero text-white">
                დეტალურად
              </Button>
            </Link>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};
