// localStorage utilities for Baghela

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'owner' | 'volunteer';
  ecoPoints: number;
  avatar?: string;
  phone?: string;
  location?: string;
  bio?: string;
  savedGardens: string[];
}

export interface Garden {
  id: string;
  ownerId: string;
  ownerName: string;
  title: string;
  description: string;
  location: string;
  type: string;
  area: number;
  soilType: string;
  images: string[];
  available: boolean;
  potentialYield: string;
  conditions: string;
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
}

export interface Contract {
  id: string;
  gardenId: string;
  gardenTitle: string;
  ownerId: string;
  volunteerId: string;
  startDate: string;
  endDate: string;
  yieldShare: number;
  notes: string;
  status: 'pending' | 'confirmed' | 'completed';
  createdAt: string;
}

export interface MarketItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
}

// User management
export const saveUser = (user: User) => {
  localStorage.setItem('baghela_user', JSON.stringify(user));
};

export const getUser = (): User | null => {
  const data = localStorage.getItem('baghela_user');
  return data ? JSON.parse(data) : null;
};

export const logout = () => {
  localStorage.removeItem('baghela_user');
};

export const updateUserPoints = (points: number) => {
  const user = getUser();
  if (user) {
    user.ecoPoints += points;
    saveUser(user);
  }
};

// Gardens management
export const getGardens = (): Garden[] => {
  const data = localStorage.getItem('baghela_gardens');
  return data ? JSON.parse(data) : [];
};

export const saveGarden = (garden: Garden) => {
  const gardens = getGardens();
  gardens.push(garden);
  localStorage.setItem('baghela_gardens', JSON.stringify(gardens));
};

export const getGardenById = (id: string): Garden | undefined => {
  const gardens = getGardens();
  return gardens.find(g => g.id === id);
};

// Messages management
export const getMessages = (conversationId: string): Message[] => {
  const data = localStorage.getItem(`baghela_messages_${conversationId}`);
  return data ? JSON.parse(data) : [];
};

export const saveMessage = (message: Message) => {
  const messages = getMessages(message.conversationId);
  messages.push(message);
  localStorage.setItem(`baghela_messages_${message.conversationId}`, JSON.stringify(messages));
};

// Contracts management
export const getContracts = (): Contract[] => {
  const data = localStorage.getItem('baghela_contracts');
  return data ? JSON.parse(data) : [];
};

export const saveContract = (contract: Contract) => {
  const contracts = getContracts();
  contracts.push(contract);
  localStorage.setItem('baghela_contracts', JSON.stringify(contracts));
};

export const updateContractStatus = (id: string, status: Contract['status']) => {
  const contracts = getContracts();
  const contract = contracts.find(c => c.id === id);
  if (contract) {
    contract.status = status;
    localStorage.setItem('baghela_contracts', JSON.stringify(contracts));
  }
};

// Initialize mock data
export const initializeMockData = () => {
  const gardens = getGardens();
  if (gardens.length === 0) {
    const mockGardens: Garden[] = [
      {
        id: '1',
        ownerId: 'owner1',
        ownerName: 'გიორგი მელაძე',
        title: 'ბოსტნეულის ბაღი თბილისში',
        description: 'მშვენიერი ბოსტნეულის ბაღი ვაკეში, სადაც შეგიძლიათ მოავლოთ ორგანულ პროდუქტებს.',
        location: 'თბილისი, ვაკე',
        type: 'ბოსტნეული',
        area: 150,
        soilType: 'ნოყიერი',
        images: ['/src/assets/garden-1.jpg'],
        available: true,
        potentialYield: '50-70 კგ სეზონზე',
        conditions: 'კვირაში 2-3 ჯერ მორწყვა, ბუნებრივი სასუქის გამოყენება',
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        ownerId: 'owner2',
        ownerName: 'ნინო ბერიძე',
        title: 'ხეხილის ბაღი მცხეთაში',
        description: 'ვაშლისა და მსხლის ხეების ბაღი ისტორიულ მცხეთაში, ულამაზესი ხედებით.',
        location: 'მცხეთა',
        type: 'ხეხილი',
        area: 300,
        soilType: 'თიხნარი',
        images: ['/src/assets/garden-2.jpg'],
        available: true,
        potentialYield: '200-300 კგ ხეხილი',
        conditions: 'ფრინველებისგან დაცვა, გაზაფხულზე შესხურება',
        createdAt: new Date().toISOString(),
      },
      {
        id: '3',
        ownerId: 'owner3',
        ownerName: 'დავით ქართველიშვილი',
        title: 'ყვავილების ბაღი ბათუმში',
        description: 'მრავალფეროვანი ყვავილების ბაღი ზღვის პანორამული ხედით.',
        location: 'ბათუმი',
        type: 'ყვავილები',
        area: 100,
        soilType: 'ქვიშნარი',
        images: ['/src/assets/garden-3.jpg'],
        available: true,
        potentialYield: 'სეზონური ყვავილები',
        conditions: 'რეგულარული მორწყვა, სარეველების მოცილება',
        createdAt: new Date().toISOString(),
      },
    ];
    localStorage.setItem('baghela_gardens', JSON.stringify(mockGardens));
  }
};
