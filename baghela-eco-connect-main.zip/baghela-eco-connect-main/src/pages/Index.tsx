import { useState, useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { GardenCard } from '@/components/GardenCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter } from 'lucide-react';
import { getGardens, initializeMockData } from '@/lib/localStorage';
import { motion } from 'framer-motion';
import heroImage from '@/assets/hero-garden.jpg';

const Index = () => {
  const [gardens, setGardens] = useState(getGardens());
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    initializeMockData();
    setGardens(getGardens());
  }, []);

  const filteredGardens = gardens.filter(garden => {
    const matchesSearch = garden.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         garden.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLocation = locationFilter === 'all' || garden.location.includes(locationFilter);
    const matchesType = typeFilter === 'all' || garden.type === typeFilter;
    
    return matchesSearch && matchesLocation && matchesType;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative h-[500px] overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={heroImage} 
            alt="Georgian Gardens"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />
        </div>
        
        <div className="relative container mx-auto px-4 h-full flex flex-col justify-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              დაუკავშირდი ბუნებას 🌿
            </h1>
            <p className="text-xl text-white/90 mb-8">
              იპოვე ბაღი შენს ახლოს და გახდი ეკო-მოძრაობის ნაწილი. 
              აღადგინე მწვანე სივრცეები და მიიღე ბუნებრივი პროდუქტები.
            </p>
            <div className="flex gap-4">
              <Button size="lg" className="gradient-hero text-white shadow-lg">
                დაიწყე ახლავე
              </Button>
              <Button size="lg" variant="outline" className="bg-white/10 text-white border-white/30 backdrop-blur-sm hover:bg-white/20">
                გაიგე მეტი
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="bg-card shadow-soft -mt-12 relative z-10 mx-4 md:mx-auto md:container rounded-3xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="მოძებნე ბაღი..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={locationFilter} onValueChange={setLocationFilter}>
            <SelectTrigger>
              <SelectValue placeholder="ადგილმდებარეობა" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ყველა ლოკაცია</SelectItem>
              <SelectItem value="თბილისი">თბილისი</SelectItem>
              <SelectItem value="მცხეთა">მცხეთა</SelectItem>
              <SelectItem value="ბათუმი">ბათუმი</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="ტიპი" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ყველა ტიპი</SelectItem>
              <SelectItem value="ბოსტნეული">ბოსტნეული</SelectItem>
              <SelectItem value="ხეხილი">ხეხილი</SelectItem>
              <SelectItem value="ყვავილები">ყვავილები</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </section>

      {/* Gardens Grid */}
      <main className="container mx-auto px-4 py-12 flex-1">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-foreground">
            ხელმისაწვდომი ბაღები
          </h2>
          <div className="text-muted-foreground">
            {filteredGardens.length} ბაღი
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGardens.map((garden, index) => (
            <GardenCard key={garden.id} garden={garden} index={index} />
          ))}
        </div>
        
        {filteredGardens.length === 0 && (
          <div className="text-center py-20">
            <p className="text-xl text-muted-foreground">ბაღები არ მოიძებნა</p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default Index;
