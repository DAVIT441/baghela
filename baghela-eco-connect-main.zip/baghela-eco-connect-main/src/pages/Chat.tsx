import { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { getUser, getMessages, saveMessage, Message, getGardenById } from '@/lib/localStorage';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { Send, MessageCircle } from 'lucide-react';

const Chat = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const user = getUser();
  const conversationId = searchParams.get('garden') || '';
  const ownerId = searchParams.get('owner') || '';
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const garden = getGardenById(conversationId);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!conversationId) {
      navigate('/');
      return;
    }
    loadMessages();
  }, [user, conversationId, navigate]);

  const loadMessages = () => {
    const msgs = getMessages(conversationId);
    setMessages(msgs);
    scrollToBottom();
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !user) return;

    const message: Message = {
      id: Date.now().toString(),
      conversationId,
      senderId: user.id,
      senderName: user.name,
      text: newMessage.trim(),
      timestamp: new Date().toISOString(),
    };

    saveMessage(message);
    setMessages([...messages, message]);
    setNewMessage('');
    toast.success('შეტყობინება გაგზავნილია');

    // Simulate owner response after 2 seconds
    if (user.id !== ownerId) {
      setTimeout(() => {
        const autoReply: Message = {
          id: (Date.now() + 1).toString(),
          conversationId,
          senderId: ownerId,
          senderName: garden?.ownerName || 'მფლობელი',
          text: 'გმადლობთ შეტყობინებისთვის! მალე გიპასუხებთ. 🌿',
          timestamp: new Date().toISOString(),
        };
        saveMessage(autoReply);
        setMessages(prev => [...prev, autoReply]);
      }, 2000);
    }
  };

  if (!user || !garden) return null;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8 flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto h-[calc(100vh-12rem)] flex flex-col"
        >
          {/* Header */}
          <div className="mb-4">
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <MessageCircle className="text-primary" />
              ჩატი
            </h1>
            <p className="text-muted-foreground">
              {garden.title} - {garden.ownerName}
            </p>
          </div>

          {/* Messages Container */}
          <Card className="flex-1 p-6 shadow-card flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {messages.length === 0 ? (
                <div className="text-center text-muted-foreground py-12">
                  <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>შეტყობინებები ჯერ არ არის</p>
                  <p className="text-sm mt-2">დაიწყე საუბარი! 🌿</p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isOwn = msg.senderId === user.id;
                  return (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, x: isOwn ? 20 : -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                          isOwn
                            ? 'bg-primary text-primary-foreground ml-auto'
                            : 'bg-muted'
                        }`}
                      >
                        <p className="text-sm font-semibold mb-1">{msg.senderName}</p>
                        <p className="break-words">{msg.text}</p>
                        <p className="text-xs opacity-70 mt-2">
                          {new Date(msg.timestamp).toLocaleTimeString('ka-GE', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </motion.div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Form */}
            <form onSubmit={handleSend} className="flex gap-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="დაწერე შეტყობინება..."
                className="flex-1"
              />
              <Button type="submit" disabled={!newMessage.trim()} className="gradient-hero text-white">
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </Card>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default Chat;
