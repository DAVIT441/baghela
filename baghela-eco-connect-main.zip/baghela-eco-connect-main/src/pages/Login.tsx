import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Leaf } from 'lucide-react';
import { getUser, saveUser } from '@/lib/localStorage';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple mock login - check localStorage for existing users
    const existingUser = getUser();
    
    if (email && password) {
      if (existingUser && existingUser.email === email) {
        toast.success('წარმატებით შეხვედით!');
        navigate('/');
      } else {
        toast.error('არასწორი ელ.ფოსტა ან პაროლი');
      }
    } else {
      toast.error('გთხოვთ შეავსოთ ყველა ველი');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="w-full max-w-md p-8 shadow-card">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 rounded-full gradient-hero flex items-center justify-center mb-4">
              <Leaf className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">შესვლა</h1>
            <p className="text-muted-foreground mt-2">მოგესალმებით ბაღელაში!</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">ელ.ფოსტა</label>
              <Input
                type="email"
                placeholder="example@mail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">პაროლი</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button type="submit" className="w-full gradient-hero text-white">
              შესვლა
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              არ გაქვთ ანგარიში?{' '}
              <Link to="/register" className="text-primary font-medium hover:underline">
                დარეგისტრირდით
              </Link>
            </p>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default Login;
