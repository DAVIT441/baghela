import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Square, Sprout, Calendar, MessageCircle } from 'lucide-react';
import { getGardenById, getUser, saveContract, saveMessage, updateUserPoints } from '@/lib/localStorage';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const GardenDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [garden, setGarden] = useState(getGardenById(id || ''));
  const [user, setUser] = useState(getUser());
  const [showChatModal, setShowChatModal] = useState(false);
  const [showContractModal, setShowContractModal] = useState(false);
  const [message, setMessage] = useState('');
  const [contractData, setContractData] = useState({
    startDate: '',
    endDate: '',
    yieldShare: 50,
    notes: '',
  });

  useEffect(() => {
    if (!garden) {
      navigate('/');
    }
  }, [garden, navigate]);

  if (!garden) return null;

  const handleSendMessage = () => {
    if (!user) {
      toast.error('გთხოვთ შეხვიდეთ სისტემაში');
      navigate('/login');
      return;
    }

    if (message.trim()) {
      toast.success('შეტყობინება გაგზავნილია!');
      setMessage('');
      setShowChatModal(false);
      // Navigate to chat page
      navigate(`/chat?garden=${garden.id}&owner=${garden.ownerId}`);
    }
  };

  const handleCreateContract = () => {
    if (!user) {
      toast.error('გთხოვთ შეხვიდეთ სისტემაში');
      navigate('/login');
      return;
    }

    if (!contractData.startDate || !contractData.endDate) {
      toast.error('გთხოვთ შეავსოთ ყველა ველი');
      return;
    }

    saveContract({
      id: Date.now().toString(),
      gardenId: garden.id,
      gardenTitle: garden.title,
      ownerId: garden.ownerId,
      volunteerId: user.id,
      startDate: contractData.startDate,
      endDate: contractData.endDate,
      yieldShare: contractData.yieldShare,
      notes: contractData.notes,
      status: 'pending',
      createdAt: new Date().toISOString(),
    });

    updateUserPoints(20);
    toast.success('შეთანხმება შექმნილია! +20 ეკო ქულა 🌿');
    setShowContractModal(false);
    navigate('/profile');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12 flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-5xl mx-auto"
        >
          {/* Garden Image */}
          <div className="rounded-3xl overflow-hidden shadow-card mb-8 h-96">
            <img 
              src={garden.images[0]} 
              alt={garden.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Info */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h1 className="text-4xl font-bold mb-4">{garden.title}</h1>
                <div className="flex flex-wrap gap-4 mb-6">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="w-5 h-5 text-primary" />
                    {garden.location}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Sprout className="w-5 h-5 text-secondary" />
                    {garden.type}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Square className="w-5 h-5 text-accent" />
                    {garden.area} მ²
                  </div>
                </div>
              </div>

              <Card className="p-6 shadow-card">
                <h2 className="text-xl font-semibold mb-3">აღწერა</h2>
                <p className="text-muted-foreground leading-relaxed">{garden.description}</p>
              </Card>

              <Card className="p-6 shadow-card">
                <h2 className="text-xl font-semibold mb-3">დეტალები</h2>
                <div className="space-y-3">
                  <div>
                    <span className="font-medium">ნიადაგის ტიპი:</span>
                    <span className="text-muted-foreground ml-2">{garden.soilType}</span>
                  </div>
                  <div>
                    <span className="font-medium">პოტენციური მოსავალი:</span>
                    <span className="text-muted-foreground ml-2">{garden.potentialYield}</span>
                  </div>
                  <div>
                    <span className="font-medium">პირობები:</span>
                    <p className="text-muted-foreground mt-1">{garden.conditions}</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card className="p-6 shadow-card gradient-card">
                <h3 className="font-semibold mb-2">მფლობელი</h3>
                <p className="text-lg mb-4">{garden.ownerName}</p>
                
                <div className="space-y-3">
                  <Button 
                    className="w-full gradient-hero text-white"
                    onClick={() => setShowChatModal(true)}
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    დაუკავშირდი მფლობელს
                  </Button>
                  
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => setShowContractModal(true)}
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    შეთანხმების შექმნა
                  </Button>
                </div>
              </Card>

              {garden.available && (
                <Card className="p-6 shadow-card bg-primary/5 border-primary/20">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-3">
                      ✓
                    </div>
                    <p className="font-semibold text-primary">ხელმისაწვდომია</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      ეს ბაღი მზადაა თანამშრომლობისთვის
                    </p>
                  </div>
                </Card>
              )}
            </div>
          </div>
        </motion.div>
      </main>

      {/* Chat Modal */}
      <Dialog open={showChatModal} onOpenChange={setShowChatModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>გაგზავნე შეტყობინება</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="დაწერე შენი შეტყობინება..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={5}
            />
            <Button 
              onClick={handleSendMessage}
              className="w-full gradient-hero text-white"
            >
              გაგზავნა
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Contract Modal */}
      <Dialog open={showContractModal} onOpenChange={setShowContractModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ციფრული შეთანხმების შექმნა</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">დაწყების თარიღი</label>
              <Input
                type="date"
                value={contractData.startDate}
                onChange={(e) => setContractData({ ...contractData, startDate: e.target.value })}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">დასრულების თარიღი</label>
              <Input
                type="date"
                value={contractData.endDate}
                onChange={(e) => setContractData({ ...contractData, endDate: e.target.value })}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">მოსავლის გაზიარება (%)</label>
              <Input
                type="number"
                min="0"
                max="100"
                value={contractData.yieldShare}
                onChange={(e) => setContractData({ ...contractData, yieldShare: parseInt(e.target.value) })}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">შენიშვნები</label>
              <Textarea
                placeholder="დამატებითი პირობები..."
                value={contractData.notes}
                onChange={(e) => setContractData({ ...contractData, notes: e.target.value })}
                rows={3}
              />
            </div>
            <Button 
              onClick={handleCreateContract}
              className="w-full gradient-hero text-white"
            >
              შექმნა
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default GardenDetail;
