import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { User, Award, Leaf, FileText, Edit } from 'lucide-react';
import { getUser, saveUser, getContracts } from '@/lib/localStorage';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(getUser());
  const [contracts, setContracts] = useState(getContracts());
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    location: user?.location || '',
    bio: user?.bio || '',
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  if (!user) return null;

  const userContracts = contracts.filter(
    c => c.ownerId === user.id || c.volunteerId === user.id
  );

  const handleSave = () => {
    const updatedUser = { ...user, ...editData };
    saveUser(updatedUser);
    setUser(updatedUser);
    setIsEditing(false);
    toast.success('პროფილი განახლებულია');
  };

  const ecoImpact = Math.floor((user.ecoPoints / 20) * 40); // 40m² per 20 points

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12 flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          {/* Profile Header */}
          <Card className="p-8 mb-6 shadow-card">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="w-24 h-24 rounded-full gradient-hero flex items-center justify-center text-white text-4xl font-bold">
                {user.name.charAt(0).toUpperCase()}
              </div>
              
              <div className="flex-1">
                {isEditing ? (
                  <div className="space-y-4">
                    <Input
                      value={editData.name}
                      onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                      placeholder="სახელი"
                    />
                    <Input
                      value={editData.phone}
                      onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                      placeholder="ტელეფონი"
                    />
                    <Input
                      value={editData.location}
                      onChange={(e) => setEditData({ ...editData, location: e.target.value })}
                      placeholder="მდებარეობა"
                    />
                    <Textarea
                      value={editData.bio}
                      onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                      placeholder="ბიოგრაფია"
                    />
                    <div className="flex gap-2">
                      <Button onClick={handleSave} className="gradient-hero text-white">
                        შენახვა
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditing(false)}>
                        გაუქმება
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
                        <p className="text-muted-foreground">{user.email}</p>
                        {user.phone && <p className="text-muted-foreground">{user.phone}</p>}
                        {user.location && <p className="text-muted-foreground">📍 {user.location}</p>}
                      </div>
                      <Button variant="outline" onClick={() => setIsEditing(true)}>
                        <Edit className="w-4 h-4 mr-2" />
                        რედაქტირება
                      </Button>
                    </div>
                    {user.bio && <p className="text-muted-foreground">{user.bio}</p>}
                    <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full mt-4">
                      {user.role === 'owner' ? '🏡 მფლობელი' : '🌱 მოხალისე'}
                    </div>
                  </>
                )}
              </div>
            </div>
          </Card>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="p-6 shadow-card">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary">{user.ecoPoints}</p>
                  <p className="text-sm text-muted-foreground">ეკო ქულა</p>
                </div>
              </div>
            </Card>

            <Card className="p-6 shadow-card">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-secondary">{userContracts.length}</p>
                  <p className="text-sm text-muted-foreground">შეთანხმება</p>
                </div>
              </div>
            </Card>

            <Card className="p-6 shadow-card">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                  <Award className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-accent">{Math.floor(user.ecoPoints / 50)}</p>
                  <p className="text-sm text-muted-foreground">მიღწევა</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Eco Impact */}
          <Card className="p-8 mb-6 shadow-card gradient-card">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Leaf className="text-primary" />
              ეკოლოგიური გავლენა
            </h2>
            <p className="text-lg text-muted-foreground">
              შენ გადაარჩინე <span className="text-primary font-bold text-2xl">{ecoImpact} მ²</span> მწვანე ტერიტორია! 🌳
            </p>
            <div className="mt-4 bg-primary/10 rounded-full h-3 overflow-hidden">
              <div 
                className="h-full gradient-hero transition-all duration-500"
                style={{ width: `${Math.min((user.ecoPoints / 100) * 100, 100)}%` }}
              />
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              შემდეგი დონის მისაღწევად: {100 - user.ecoPoints} ქულა
            </p>
          </Card>

          {/* Contracts */}
          <Card className="p-8 shadow-card">
            <h2 className="text-2xl font-bold mb-6">ჩემი შეთანხმებები</h2>
            {userContracts.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                თქვენ ჯერ არ გაქვთ აქტიური შეთანხმებები
              </p>
            ) : (
              <div className="space-y-4">
                {userContracts.map(contract => (
                  <div key={contract.id} className="border rounded-2xl p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold">{contract.gardenTitle}</h3>
                      <span className={`px-3 py-1 rounded-full text-sm ${
                        contract.status === 'confirmed' ? 'bg-primary/10 text-primary' :
                        contract.status === 'completed' ? 'bg-secondary/10 text-secondary' :
                        'bg-muted text-muted-foreground'
                      }`}>
                        {contract.status === 'confirmed' ? 'დადასტურებული' :
                         contract.status === 'completed' ? 'დასრულებული' :
                         'მომლოდინე'}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      📅 {new Date(contract.startDate).toLocaleDateString('ka-GE')} - {new Date(contract.endDate).toLocaleDateString('ka-GE')}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      🌾 მოსავლის გაზიარება: {contract.yieldShare}%
                    </p>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default Profile;
