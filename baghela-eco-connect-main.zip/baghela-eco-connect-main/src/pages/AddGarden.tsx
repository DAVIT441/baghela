import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getUser, saveGarden, Garden } from '@/lib/localStorage';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { PlusCircle, Upload } from 'lucide-react';

const AddGarden = () => {
  const navigate = useNavigate();
  const user = getUser();
  const [imagePreview, setImagePreview] = useState<string>('');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    type: '',
    area: '',
    soilType: '',
    potentialYield: '',
    conditions: '',
  });

  useEffect(() => {
    if (!user || user.role !== 'owner') {
      toast.error('მხოლოდ მფლობელებს შეუძლიათ ბაღის დამატება');
      navigate('/');
    }
  }, [user, navigate]);

  if (!user || user.role !== 'owner') return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.description || !formData.location || !formData.type) {
      toast.error('გთხოვთ შეავსოთ ყველა სავალდებულო ველი');
      return;
    }

    const newGarden: Garden = {
      id: Date.now().toString(),
      ownerId: user.id,
      ownerName: user.name,
      title: formData.title,
      description: formData.description,
      location: formData.location,
      type: formData.type,
      area: Number(formData.area) || 0,
      soilType: formData.soilType,
      images: imagePreview ? [imagePreview] : ['/src/assets/garden-1.jpg'],
      available: true,
      potentialYield: formData.potentialYield,
      conditions: formData.conditions,
      createdAt: new Date().toISOString(),
    };

    saveGarden(newGarden);
    toast.success('ბაღი წარმატებით დაემატა! 🌿');
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12 flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl mx-auto"
        >
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
              <PlusCircle className="text-primary" />
              ახალი ბაღის დამატება
            </h1>
            <p className="text-muted-foreground">
              გააზიარე შენი ბაღი და იპოვე მოხალისეები მის მოვლისთვის
            </p>
          </div>

          <Card className="p-8 shadow-card">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Image Upload */}
              <div>
                <Label htmlFor="image">ფოტო</Label>
                <div className="mt-2">
                  <label htmlFor="image" className="cursor-pointer">
                    <div className="border-2 border-dashed rounded-2xl p-8 text-center hover:border-primary transition-smooth">
                      {imagePreview ? (
                        <img src={imagePreview} alt="Preview" className="w-full h-48 object-cover rounded-xl mb-4" />
                      ) : (
                        <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                      )}
                      <p className="text-sm text-muted-foreground">
                        {imagePreview ? 'ფოტოს შეცვლა' : 'ატვირთე ფოტო'}
                      </p>
                    </div>
                    <input
                      id="image"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageUpload}
                    />
                  </label>
                </div>
              </div>

              {/* Title */}
              <div>
                <Label htmlFor="title">სათაური *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="მაგ: ბოსტნეულის ბაღი თბილისში"
                  required
                />
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description">აღწერა *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="აღწერე შენი ბაღი, რა სახის მცენარეები იზრდება აქ..."
                  rows={4}
                  required
                />
              </div>

              {/* Location and Type */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="location">მდებარეობა *</Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="მაგ: თბილისი, ვაკე"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="type">ბაღის ტიპი *</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიე ტიპი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ბოსტნეული">ბოსტნეული</SelectItem>
                      <SelectItem value="ხეხილი">ხეხილი</SelectItem>
                      <SelectItem value="ყვავილები">ყვავილები</SelectItem>
                      <SelectItem value="სანელებლები">სანელებლები</SelectItem>
                      <SelectItem value="შერეული">შერეული</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Area and Soil Type */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="area">ფართობი (მ²)</Label>
                  <Input
                    id="area"
                    type="number"
                    value={formData.area}
                    onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                    placeholder="მაგ: 150"
                  />
                </div>

                <div>
                  <Label htmlFor="soilType">ნიადაგის ტიპი</Label>
                  <Select value={formData.soilType} onValueChange={(value) => setFormData({ ...formData, soilType: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიე ტიპი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ნოყიერი">ნოყიერი</SelectItem>
                      <SelectItem value="თიხნარი">თიხნარი</SelectItem>
                      <SelectItem value="ქვიშნარი">ქვიშნარი</SelectItem>
                      <SelectItem value="ლორნარი">ლორნარი</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Potential Yield */}
              <div>
                <Label htmlFor="potentialYield">მოსალოდნელი მოსავალი</Label>
                <Input
                  id="potentialYield"
                  value={formData.potentialYield}
                  onChange={(e) => setFormData({ ...formData, potentialYield: e.target.value })}
                  placeholder="მაგ: 50-70 კგ სეზონზე"
                />
              </div>

              {/* Conditions */}
              <div>
                <Label htmlFor="conditions">მოვლის პირობები</Label>
                <Textarea
                  id="conditions"
                  value={formData.conditions}
                  onChange={(e) => setFormData({ ...formData, conditions: e.target.value })}
                  placeholder="მაგ: კვირაში 2-3 ჯერ მორწყვა, ბუნებრივი სასუქის გამოყენება"
                  rows={3}
                />
              </div>

              {/* Buttons */}
              <div className="flex gap-4 pt-4">
                <Button type="submit" className="flex-1 gradient-hero text-white">
                  <PlusCircle className="w-4 h-4 mr-2" />
                  ბაღის დამატება
                </Button>
                <Button type="button" variant="outline" onClick={() => navigate('/')}>
                  გაუქმება
                </Button>
              </div>
            </form>
          </Card>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default AddGarden;
