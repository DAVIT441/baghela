import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card } from '@/components/ui/card';
import { Sprout, Scissors, Package } from 'lucide-react';
import { motion } from 'framer-motion';

const seasons = [
  {
    month: 'იანვარი-თებერვალი',
    season: 'ზამთარი',
    tasks: ['თოვლის მოცილება', 'ხეების გასხვლა', 'იარაღების მომზადება'],
    icon: Scissors,
  },
  {
    month: 'მარტი-აპრილი',
    season: 'გაზაფხული',
    tasks: ['თესვის დაწყება', 'ნიადაგის მოსამზადებელი', 'ნერგების დარგვა'],
    icon: Sprout,
  },
  {
    month: 'მაისი-ივნისი',
    season: 'გაზაფხული-ზაფხული',
    tasks: ['სარწყავი სისტემის დამონტაჟება', 'მცენარეების მოვლა', 'სარეველების მოცილება'],
    icon: Sprout,
  },
  {
    month: 'ივლისი-აგვისტო',
    season: 'ზაფხული',
    tasks: ['მორწყვა', 'მოსავლის დაწყება', 'კომპოსტირება'],
    icon: Package,
  },
  {
    month: 'სექტემბერი-ოქტომბერი',
    season: 'შემოდგომა',
    tasks: ['ძირითადი მოსავალი', 'შემოდგომის თესვა', 'ნიადაგის გაუმჯობესება'],
    icon: Package,
  },
  {
    month: 'ნოემბერი-დეკემბერი',
    season: 'შემოდგომა-ზამთარი',
    tasks: ['ზამთრის მომზადება', 'მცენარეების დაფარვა', 'ხელსაწყოების შენახვა'],
    icon: Scissors,
  },
];

const Calendar = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12 flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="max-w-4xl mx-auto mb-12 text-center">
            <h1 className="text-4xl font-bold mb-4">სეზონური კალენდარი 📅</h1>
            <p className="text-xl text-muted-foreground">
              წლის განმავლობაში ბაღში სამუშაოების დაგეგმვა
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {seasons.map((season, index) => (
              <motion.div
                key={season.month}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 shadow-card hover:shadow-hover transition-smooth h-full">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-12 h-12 rounded-2xl gradient-hero flex items-center justify-center flex-shrink-0">
                      <season.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-1">{season.month}</h3>
                      <span className="text-sm bg-primary/10 text-primary px-3 py-1 rounded-full">
                        {season.season}
                      </span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {season.tasks.map((task, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <span className="text-primary mt-1">•</span>
                        <span className="text-muted-foreground">{task}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Tips Section */}
          <Card className="mt-12 p-8 shadow-card gradient-card max-w-5xl mx-auto">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Sprout className="text-primary" />
              რჩევები წარმატებული მოსავლისთვის
            </h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>დაიცავით სეზონური თესვის გრაფიკი თქვენი რეგიონისთვის</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>გამოიყენეთ ბუნებრივი სასუქები ნიადაგის ნაყოფიერების გასაუმჯობესებლად</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>დაიცავით მცენარეთა კულტურის როტაცია უკეთესი მოსავლისთვის</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>რეგულარულად შეამოწმეთ მავნებლები და დაავადებები</span>
              </li>
            </ul>
          </Card>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default Calendar;
