import { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingBag, Sprout, Package, Droplets } from 'lucide-react';
import { getUser, updateUserPoints } from '@/lib/localStorage';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const marketItems = [
  {
    id: '1',
    name: 'ორგანული თესლი',
    description: 'პომიდვრის, კიტრის და წიწაკის თესლების ნაკრები',
    price: 50,
    icon: Sprout,
    category: 'თესლი',
  },
  {
    id: '2',
    name: 'ნერგების ნაკრები',
    description: 'სეზონური ბოსტნეულის ნერგები (10 ცალი)',
    price: 80,
    icon: Package,
    category: 'ნერგები',
  },
  {
    id: '3',
    name: 'ბიო სასუქი',
    description: 'ბუნებრივი ორგანული სასუქი 5კგ',
    price: 120,
    icon: Droplets,
    category: 'სასუქი',
  },
  {
    id: '4',
    name: 'ბაღის ხელსაწყოები',
    description: 'ძირითადი ბაღის ხელსაწყოების კომპლექტი',
    price: 200,
    icon: ShoppingBag,
    category: 'ხელსაწყოები',
  },
];

const Market = () => {
  const [user, setUser] = useState(getUser());

  const handlePurchase = (item: typeof marketItems[0]) => {
    if (!user) {
      toast.error('გთხოვთ შეხვიდეთ სისტემაში');
      return;
    }

    if (user.ecoPoints < item.price) {
      toast.error('არასაკმარისი ქულები');
      return;
    }

    updateUserPoints(-item.price);
    setUser(getUser());
    toast.success(`${item.name} შეძენილია!`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12 flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="max-w-4xl mx-auto mb-12 text-center">
            <h1 className="text-4xl font-bold mb-4">Green Marketplace 🌿</h1>
            <p className="text-xl text-muted-foreground mb-6">
              გამოიყენე ეკო ქულები ბაღის საჭირო ნივთების შესაძენად
            </p>
            {user && (
              <div className="inline-block bg-primary/10 text-primary px-6 py-3 rounded-full">
                <span className="text-lg font-semibold">შენი ქულები: {user.ecoPoints} 🌿</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {marketItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 shadow-card hover:shadow-hover transition-smooth">
                  <div className="flex gap-4">
                    <div className="w-16 h-16 rounded-2xl gradient-hero flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-8 h-8 text-white" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="text-xl font-semibold mb-1">{item.name}</h3>
                          <span className="text-xs bg-secondary/10 text-secondary px-2 py-1 rounded-full">
                            {item.category}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">{item.price}</div>
                          <div className="text-xs text-muted-foreground">ქულა</div>
                        </div>
                      </div>
                      
                      <p className="text-muted-foreground text-sm mb-4">
                        {item.description}
                      </p>
                      
                      <Button 
                        onClick={() => handlePurchase(item)}
                        className="w-full gradient-hero text-white"
                        disabled={!user || user.ecoPoints < item.price}
                      >
                        შეძენა
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default Market;
